<?php
$db = new PDO('mysql:host=localhost;dbname=binapp','root','');
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

$binids = array();
$binids= $_GET['binids']; //echo $binids;
$fromdate=$_GET['fromdate']; //echo $fromdate;
$todate=$_GET['todate'];//echo $todate;
$fill=$_GET['fill'];//echo $fill;
$humidity=$_GET['humidity'];//echo $humidity;
$temperature=$_GET['temperature']; //echo $temperature;
$myArray = array();
$myArray["data"] = array();

foreach ($binids as $binid){
	echo $binid;
	
	if 
	
	$sql = "SELECT DateTime, Fill FROM `analysis` WHERE BinId=:binid
	$params = array(
        'area' => $area        
    );
	
	$points = $db->prepare($sql);
	$points->execute($params);
	while($row = $points->fetch(PDO::FETCH_ASSOC)) {
		array_push($myArray["bins"], $row);
	}
	
}



	


$myArray["success"]=1;
echo json_encode($myArray);
?>