<?php
$db = new PDO('mysql:host=localhost;dbname=binapp','root','');
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

$area = $_GET['area']; // get data for required area
$myArray = array();

$sql = "SELECT * FROM bins WHERE UCASE(Location) LIKE :area";
$params = array(
        'area' => $area        
    );

$points = $db->prepare($sql);
$points->execute($params);
	
$myArray = array();
$myArray["bins"] = array();
while($row = $points->fetch(PDO::FETCH_ASSOC)) {
		array_push($myArray["bins"], $row);
}
$myArray["success"]=1;
echo json_encode($myArray);
?>