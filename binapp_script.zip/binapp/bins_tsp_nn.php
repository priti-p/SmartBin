<?php

	class Stack {
		private $_stack = array();
		public function size() {
			return count($this->_stack);
		}
		public function peek() {
			return end($this->_stack);
		}
		public function push($value = NULL) {
			array_push($this->_stack, $value);
		}
		public function pop() {
			return array_pop($this->_stack);
		}
		public function isEmpty() {
			return empty($this->_stack);
		}
	}
	
	class TSPNearestNeighbour {
	
		private $numberOfNodes;

        public $stack; 

		public function __construct()
		{
			$this->stack = new Stack(); 
		}
		
		public function tsp($distMatrix)
		{
			$keys = array_keys($distMatrix);
			$numberOfNodes = count($keys);
			$visited = array_fill(0, $numberOfNodes, 0);
			$visited[0] = 1;
			$this->stack->push($keys[0]);
			$dst=0;
			$min=PHP_INT_MAX ;
			$minflag = False;
			$output_array  = array();
			array_push($output_array,$keys[0]);
			while(!$this->stack->isEmpty())
			{
				$element = $this->stack->peek();
				$i=1;
				
				$min=PHP_INT_MAX;
				while($i < $numberOfNodes )
				{
					$j = $keys[$i];
					if($distMatrix[$element][$j]>=0 and $visited[$i]==0)
					{
					
						if ($min > $distMatrix[$element][$j])

						{

							$min = $distMatrix[$element][$j];

							$dst = $i;

							$minFlag = True;

						}
					}
					$i=$i+1;
				}
				
				if ($minFlag)

                {

                    $visited[$dst] = 1;

                    $this->stack->push($keys[$dst]);
					array_push($output_array,$keys[$dst]);

                    $minFlag = False;

                    continue;

                }

                $this->stack->pop();
			}

			return $output_array;
		}
	}
	
class TSP {


	private $locations 	= array();		// all locations to visit
	private $longitudes = array();
	private $latitudes 	= array();
	private $shortest_route = array();	// holds the shortest route
	private $shortest_routes = array();	// any matching shortest routes
	private $shortest_distance = 0;		// holds the shortest distance
	private $all_routes = array();		// array of all the possible combinations and there distances
	private $adj_matrix = array();

	// add a location
	public function add($name,$longitude,$latitude){
		$this->locations[$name] = array('longitude'=>$longitude,'latitude'=>$latitude);
	}
	
	public function make_matrix($locations)
	{
		
		foreach ($locations as $location=>$coords){
			$this->longitudes[$location] = $coords['longitude'];
			$this->latitudes[$location] = $coords['latitude'];
		}
		
		foreach (array_keys($locations) as $row) {
			foreach (array_keys($locations) as $col)
			{
				$adj_matrix[$row][$col] = $this->distance($this->latitudes[$row],$this->longitudes[$row],$this->latitudes[$col],$this->longitudes[$col]);
			}
        }
	
		return $adj_matrix;
	}
	// the main function that des the calculations
	public function compute(){
		$locations = $this->locations;
	$result = array();
	$dis_matrix=$this->make_matrix($locations);
	$tspNearestNeighbour = new TSPNearestNeighbour;
	$result = $tspNearestNeighbour->tsp($dis_matrix);
	return $result;
	}
	// work out the distance between 2 longitude and latitude pairs
	function distance($lat1, $lon1, $lat2, $lon2) { 
		if ($lat1 == $lat2 && $lon1 == $lon2) return 0;
		$unit = 'M';	// miles please!
		$theta = $lon1 - $lon2; 
		$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta)); 
		$dist = acos($dist); 
		$dist = rad2deg($dist); 
		$miles = $dist * 60 * 1.1515;
		$unit = strtoupper($unit);


		if ($unit == "K") {
			return ($miles * 1.609344); 
		} else if ($unit == "N") {
			return ($miles * 0.8684);
		} else {
			return $miles;
		}
	}
	// work out all the possible different permutations of an array of data
	private function array_permutations($items, $perms = array( )) {
		static $all_permutations;
		if (empty($items)) {
			$all_permutations[] = $perms;
		}  else {
			for ($i = count($items) - 1; $i >= 0; --$i) {
				$newitems = $items;
				$newperms = $perms;
				list($foo) = array_splice($newitems, $i, 1);
				array_unshift($newperms, $foo);
				$this->array_permutations($newitems, $newperms);
			}
		}
		return $all_permutations;
	}
	// return an array of the shortest possible route
	public function shortest_route(){
		return $this->shortest_route;
	}
	// returns an array of any routes that are exactly the same distance as the shortest (ie the shortest backwards normally)
	public function matching_shortest_routes(){
		return $this->shortest_routes;
	}
	// the shortest possible distance to travel
	public function shortest_distance(){
		return $this->shortest_distance;
	}
	// returns an array of all the possible routes
	public function routes(){
		return $this->all_routes;
	}
}

$tsp = new TSP;

$db = new PDO('mysql:host=localhost;dbname=binapp','root','');
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

	$lat = $_GET['lat']; // latitude of centre of bounding circle in degrees
    $lon = $_GET['lon']; // longitude of centre of bounding circle in degrees
    $rad = $_GET['rad']; // radius of bounding circle in kilometers

    $R = 6371;  // earth's mean radius, km

    // first-cut bounding box (in degrees)
    $maxLat = $lat + rad2deg($rad/$R);
    $minLat = $lat - rad2deg($rad/$R);
    // compensate for degrees longitude getting smaller with increasing latitude
    $maxLon = $lon + rad2deg($rad/$R/cos(deg2rad($lat)));
    $minLon = $lon - rad2deg($rad/$R/cos(deg2rad($lat)));

    $sql = "Select Id, Latitude,Longitutde, Fill,
                acos(sin(:lat)*sin(radians(Latitude)) + cos(:lat)*cos(radians(Latitude))*cos(radians(Longitutde)-:lon)) * :R As D
            From (
                Select Id, Fill, Latitude, Longitutde
                From bins
                Where Latitude Between :minLat And :maxLat
                  And Longitutde Between :minLon And :maxLon
            ) As FirstCut
            Where acos(sin(:lat)*sin(radians(Latitude)) + cos(:lat)*cos(radians(Latitude))*cos(radians(Longitutde)-:lon)) * :R < :rad
            Order by D";
    $params = array(
        'lat'    => deg2rad($lat),
        'lon'    => deg2rad($lon),
        'minLat' => $minLat,
        'minLon' => $minLon,
        'maxLat' => $maxLat,
        'maxLon' => $maxLon,
        'rad'    => $rad,
        'R'      => $R,
    );
    $points = $db->prepare($sql);
    $points->execute($params);

    while($row = $points->fetch(PDO::FETCH_ASSOC)) {
			$tsp->add($row["Id"],$row["Latitude"],$row["Longitutde"]);
			
    }
	$Output = array();
$Output = $tsp->compute();

$myArray = array();
	$myArray["bins"] = array();
	
foreach ($Output as $key => $val) {
 $sql_final = "Select Id, Latitude,Longitutde, Fill
            From bins
            WHERE Id=$val";
    $stmt = $db->prepare($sql_final);
	// bindvalue is 1-indexed, so $k+1
	//foreach ($Output as $k => $id)
    //$stmt->bindValue(($k+1), $id);
    $stmt->execute();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($myArray["bins"], $row);
    }
	}
	$myArray["success"]=1;
    echo json_encode($myArray);
?>